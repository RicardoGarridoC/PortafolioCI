<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class SesionEquipoTecnico implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (!session()->has('emailUsuario')) {
            return redirect()->to('/');
        }

        $model = model('UsuarioModel');
        $user = $model->select('rol')->where('email', session()->get('emailUsuario'))->get()->getRow();

        if ($user !== null && property_exists($user, 'rol') && $user->rol === 'equipo_tecnico') {
            // El usuario tiene el rol de "equipo_tecnico", permitir el acceso
            return;
        } else {
            // El usuario no tiene el rol de "equipo_tecnico", redirigir al inicio
            return redirect()->to('/');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No es necesario hacer nada después del procesamiento de la solicitud
    }
}

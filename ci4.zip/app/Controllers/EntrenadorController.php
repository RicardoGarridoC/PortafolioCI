<?php

namespace App\Controllers;


class EntrenadorDashboard extends BaseController
{
    public function entrenadorDashboard()
    {
        return view('');
    }

    public function __construct()
    {
        helper('form');
    }
    
}

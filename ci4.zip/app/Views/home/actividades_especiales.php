<style>
    body {
        background-color: #333;
        color: #fff;
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .card {
        background-color: #444;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
    }

    h1, h2, h3 {
        color: #fff;
        text-align: center;
    }

    hr {
        border: none;
        border-top: 1px solid #666;
        margin: 20px 0;
    }

    p {
        line-height: 1.5;
        color: #fff;
    }

    .activities-list {
        margin-top: 20px;
    }

    .activity-item {
        margin-bottom: 10px;
        color: #fff;
    }

    .activity-item-icon {
        margin-right: 10px;
    }
</style>

<br>
<div class="container">
    <div class="card">
        <center><h1>Bingo Familiar "Unidos por el Futbol Femenino"</h1></center>
        <hr>
        <h2>¡Diviértete y apoya a Los Alces FC!</h2>
        <br>
        <p><strong>Fecha:</strong> Sábado, 15 de Julio de 2023</p>
        <p><strong>Lugar:</strong> Chiguayante Sur, Calle 4, 584</p>
        <p><strong>Descripción:</strong></p>
        <p>Únete a nosotros en una tarde llena de diversión y solidaridad en el Bingo Familiar "Unidos por el Futbol Femenino".</p>
        <p>Este evento especial se llevará a cabo con el objetivo de recaudar fondos para el equipo de fútbol femenino de Los Alces FC, ayudándoles a adquirir equipamiento de calidad y asegurar el pago de sueldos a las talentosas jugadoras.</p>
        <p>El Bingo Familiar es una oportunidad única para disfrutar en familia de emocionantes partidas de bingo y actividades especiales. Además, habrá premios sorpresa para los ganadores y actividades para niños, asegurando un momento agradable para todos los asistentes.</p>
        <p>¡No te pierdas esta oportunidad de pasar un buen rato, apoyar el deporte femenino y contribuir al crecimiento de Los Alces FC!</p>
        <p><strong>Valor de Acceso:</strong> $10,000 por persona</p>
        <div class="activities-list">
            <h3>Actividades y Premios Sorpresa</h3>
            <div class="activity-item">
                <span class="activity-item-icon">&#127881;</span>
                Sorteo de camisetas oficiales de Los Alces FC.
            </div>
            <div class="activity-item">
                <span class="activity-item-icon">&#127919;</span>
                Bingo con increíbles premios, incluyendo entradas a partidos y productos deportivos.
            </div>
            <div class="activity-item">
                <span class="activity-item-icon">&#127942;</span>
                Rifa de una cena para dos personas en un reconocido restaurante local.
            </div>
            <div class="activity-item">
                <span class="activity-item-icon">&#127894;</span>
                Actividades recreativas para niños, como pintacaras y globoflexia.
            </div>
            <div class="activity-item">
                <span class="activity-item-icon">&#127881;</span>
                Exhibición de habilidades y destrezas de las jugadoras del equipo femenino de Los Alces FC.
            </div>
        </div>
    </div>
</div>
<br>

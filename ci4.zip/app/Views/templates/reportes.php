<?= $this->extend('layout/sidebarsocio') ?>

<?= $this->section('contenido') ?>

  <!--Colocar Contenido Aqui-->


<?= $this->endSection() ?>
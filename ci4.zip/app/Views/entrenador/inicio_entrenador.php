<?= $this->extend('layout/sidebarsocio') ?>

<?= $this->section('contenido') ?>

  

<?= $this->endSection() ?>
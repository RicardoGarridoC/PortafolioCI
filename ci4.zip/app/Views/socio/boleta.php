<!DOCTYPE html>
<html>

<head>
    <title>Boleta</title>
    <style>
        /* Estilos CSS para la boleta */
    </style>
</head>

<body>
    <h1>Boleta</h1>
    <p>monto: <?= $datos['monto'] ?></p>
    <p>fecha: <?= $datos['fecha'] ?></p>
    <p>detalle: <?= $datos['detalle'] ?></p>

</body>

</html>
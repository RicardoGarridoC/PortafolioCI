<?= $this->extend('layout/admin_template') ?>
<?= $this->section('content') ?>


<?= $this->endSection() ?>
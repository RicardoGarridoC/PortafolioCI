<?php namespace App\Models;

use CodeIgniter\Model;

class PartidosModel extends Model
{
    protected $table = 'vista_partidos_hasta_hoy';
}
?>